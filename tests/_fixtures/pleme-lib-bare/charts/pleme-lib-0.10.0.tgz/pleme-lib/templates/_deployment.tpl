{{/*
pleme-lib: deployment named template

Produces a standard Deployment for pleme-io services.

When `.Values.compliance.baseline` is set, the deployment is rendered with
baseline-driven hardening (seccomp, automount, image-digest, topology spread,
audit annotations) and validated at template time — non-compliant values
fail with an explicit error.
*/}}

{{- define "pleme-lib.deployment" -}}
{{- include "pleme-lib.compliance.validate" . -}}
apiVersion: apps/v1
kind: Deployment
metadata:
  name: {{ include "pleme-lib.fullname" . }}
  namespace: {{ include "pleme-lib.namespace" . }}
  labels:
    {{- include "pleme-lib.labels" . | nindent 4 }}
  {{- $resAnnotations := include "pleme-lib.resourceAnnotations" . }}
  {{- if $resAnnotations }}
  annotations:
    {{- $resAnnotations | nindent 4 }}
  {{- end }}
spec:
  {{- if not (.Values.autoscaling).enabled }}
  replicas: {{ .Values.replicaCount | default 1 }}
  {{- end }}
  selector:
    matchLabels:
      {{- include "pleme-lib.selectorLabels" . | nindent 6 }}
  {{- with .Values.strategy }}
  strategy:
    {{- toYaml . | nindent 4 }}
  {{- end }}
  template:
    metadata:
      labels:
        {{- include "pleme-lib.selectorLabels" . | nindent 8 }}
        app: {{ include "pleme-lib.fullname" . }}
        {{- $cl := include "pleme-lib.compliance.labels" . | trim }}
        {{- if $cl }}
        {{- $cl | nindent 8 }}
        {{- end }}
      annotations:
        {{- include "pleme-lib.prometheusAnnotations" . | nindent 8 }}
        {{- include "pleme-lib.istioAnnotations" . | nindent 8 }}
        {{- include "pleme-lib.compliance.annotations" . | nindent 8 }}
        {{- include "pleme-lib.compliance.audit.annotations" . | nindent 8 }}
        {{- with .Values.podAnnotations }}
        {{- toYaml . | nindent 8 }}
        {{- end }}
    spec:
      serviceAccountName: {{ include "pleme-lib.serviceAccountName" . }}
      automountServiceAccountToken: {{ include "pleme-lib.compliance.automountServiceAccountToken" . }}
      {{- $airgapSecrets := include "pleme-lib.compliance.airgap.imagePullSecrets" . | trim }}
      {{- if or .Values.imagePullSecrets $airgapSecrets }}
      imagePullSecrets:
        {{- with .Values.imagePullSecrets }}
        {{- toYaml . | nindent 8 }}
        {{- end }}
        {{- if $airgapSecrets }}
        {{- $airgapSecrets | nindent 8 }}
        {{- end }}
      {{- end }}
      securityContext:
        {{- include "pleme-lib.podSecurityContext" . | nindent 8 }}
      {{- if or (.Values.shinkaWait).enabled (gt (len (.Values.initContainers | default list)) 0) }}
      initContainers:
        {{- include "pleme-lib.shinkaWaitInitContainer" . | nindent 8 }}
        {{- with .Values.initContainers }}
        {{- toYaml . | nindent 8 }}
        {{- end }}
      {{- end }}
      containers:
        - name: {{ include "pleme-lib.name" . }}
          image: {{ include "pleme-lib.compliance.image" . }}
          imagePullPolicy: {{ include "pleme-lib.compliance.image.pullPolicy" . }}
          {{- with .Values.command }}
          command:
            {{- toYaml . | nindent 12 }}
          {{- end }}
          {{- with .Values.args }}
          args:
            {{- toYaml . | nindent 12 }}
          {{- end }}
          {{- with .Values.ports }}
          ports:
            {{- toYaml . | nindent 12 }}
          {{- end }}
          {{- /* pleme-lib 0.9.0+: pod env contributions come from each
                applied overlay's `podEnv` surface (e.g. fips overlay
                injects FIPS-mode env vars). Aggregated via dispatch. */ -}}
          {{- $overlayEnv := include "pleme-lib.overlay.dispatchAll" (list "podEnv" .) | trim }}
          {{- if or (or (.Values.downwardApi).enabled (gt (len (.Values.env | default list)) 0)) $overlayEnv }}
          env:
            {{- if (.Values.downwardApi).enabled }}
            - name: POD_NAME
              valueFrom:
                fieldRef:
                  fieldPath: metadata.name
            - name: POD_NAMESPACE
              valueFrom:
                fieldRef:
                  fieldPath: metadata.namespace
            - name: NODE_NAME
              valueFrom:
                fieldRef:
                  fieldPath: spec.nodeName
            {{- end }}
            {{- if $overlayEnv }}
            {{- $overlayEnv | nindent 12 }}
            {{- end }}
            {{- with .Values.env }}
            {{- toYaml . | nindent 12 }}
            {{- end }}
          {{- end }}
          {{- with .Values.envFrom }}
          envFrom:
            {{- toYaml . | nindent 12 }}
          {{- end }}
          {{- with .Values.resources }}
          resources:
            {{- toYaml . | nindent 12 }}
          {{- end }}
          securityContext:
            {{- include "pleme-lib.containerSecurityContext" . | nindent 12 }}
          livenessProbe:
            {{- include "pleme-lib.livenessProbe" . | nindent 12 }}
          readinessProbe:
            {{- include "pleme-lib.readinessProbe" . | nindent 12 }}
          {{- if (.Values.startupProbe).enabled }}
          startupProbe:
            {{- include "pleme-lib.startupProbe" . | nindent 12 }}
          {{- end }}
          {{- with .Values.volumeMounts }}
          volumeMounts:
            {{- toYaml . | nindent 12 }}
          {{- end }}
          {{- with .Values.lifecycle }}
          lifecycle:
            {{- toYaml . | nindent 12 }}
          {{- end }}
        {{- range .Values.sidecars }}
        - {{- toYaml . | nindent 10 }}
        {{- end }}
      {{- with .Values.volumes }}
      volumes:
        {{- toYaml . | nindent 8 }}
      {{- end }}
      terminationGracePeriodSeconds: {{ .Values.terminationGracePeriodSeconds | default 30 }}
      {{- with .Values.priorityClassName }}
      priorityClassName: {{ . }}
      {{- end }}
      {{- $availReq := include "pleme-lib.compliance.availability.required" . }}
      {{- if or .Values.topologySpreadConstraints (eq $availReq "true") }}
      topologySpreadConstraints:
      {{- if eq $availReq "true" }}
      {{- include "pleme-lib.compliance.availability.topologySpread" . | nindent 8 }}
      {{- else }}
        {{- toYaml .Values.topologySpreadConstraints | nindent 8 }}
      {{- end }}
      {{- end }}
      {{- with .Values.nodeSelector }}
      nodeSelector:
        {{- toYaml . | nindent 8 }}
      {{- end }}
      {{- with .Values.tolerations }}
      tolerations:
        {{- toYaml . | nindent 8 }}
      {{- end }}
      {{- with .Values.affinity }}
      affinity:
        {{- toYaml . | nindent 8 }}
      {{- end }}
{{- end }}
